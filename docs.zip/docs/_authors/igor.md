---
short_name: igor
name: Igor Monteiro Vieira
position: Editor
---
Igor is an avid fan of quantum and devops way of thinking.